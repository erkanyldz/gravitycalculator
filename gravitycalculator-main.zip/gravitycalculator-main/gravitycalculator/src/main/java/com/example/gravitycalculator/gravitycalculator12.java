package com.example.gravitycalculator;

public class gravitycalculator12 {public class gravitycalculator12 {

}
